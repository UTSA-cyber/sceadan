/bin/rm -rf out-1
python3 sceadan_train.py --data ../test_data --trainexe ../liblinear/train --exp out-1
