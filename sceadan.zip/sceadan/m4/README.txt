This directory is used by autoconf.
